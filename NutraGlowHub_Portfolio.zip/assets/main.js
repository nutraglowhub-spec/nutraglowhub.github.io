// Simple fade-in on scroll
document.addEventListener('DOMContentLoaded', function(){
  const cards = document.querySelectorAll('.card, .hero, .about, .contact, .testimonials');
  const observer = new IntersectionObserver((entries)=>{
    entries.forEach(entry=>{
      if(entry.isIntersecting){
        entry.target.classList.add('fade-in');
      }
    });
  }, {threshold:0.15});
  cards.forEach(c=>observer.observe(c));
});
